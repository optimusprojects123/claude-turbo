#!/usr/bin/env python3
"""
TurboCode Hook
- Simple, reliable hook for Claude Code permission handling
- Turbo Mode: auto-allows all permission requests instantly
- Normal Mode: forwards to TurboCode app for manual approval

Config: ~/.claude/claude-island-config.json
{
    "turbo_mode": false,
    "auto_allow_delay_seconds": 0
}

turbo_mode: true  = auto-allow everything, no prompts
turbo_mode: false = show notification in app, wait for user
auto_allow_delay_seconds: 0 = instant auto-allow (turbo mode)
                          3 = wait 3s for user to deny, then auto-allow
"""
import json
import os
import socket
import sys

SOCKET_PATH = "/tmp/claude-island.sock"
CONFIG_PATH = os.path.expanduser("~/.claude/claude-island-config.json")


def read_config():
    """Read config fresh on every invocation."""
    defaults = {
        "turbo_mode": False,
        "auto_allow_delay_seconds": 0,
    }
    try:
        with open(CONFIG_PATH, "r") as f:
            config = json.load(f)
        return {**defaults, **config}
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return defaults


def allow():
    """Print allow decision and exit."""
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PermissionRequest",
            "decision": {"behavior": "allow"},
        }
    }))
    sys.exit(0)


def deny(reason="Denied by user"):
    """Print deny decision and exit."""
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PermissionRequest",
            "decision": {
                "behavior": "deny",
                "message": reason,
            },
        }
    }))
    sys.exit(0)


def notify_app(state):
    """Send state to TurboCode app via socket (fire and forget)."""
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(2)
        sock.connect(SOCKET_PATH)
        sock.sendall(json.dumps(state).encode())
        sock.close()
    except (socket.error, OSError):
        pass


def notify_and_wait(state, timeout):
    """Send state to app and wait for user response within timeout."""
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect(SOCKET_PATH)
        sock.sendall(json.dumps(state).encode())
        response = sock.recv(4096)
        sock.close()
        if response:
            return json.loads(response.decode())
    except socket.timeout:
        return None
    except (socket.error, OSError, json.JSONDecodeError):
        return None
    return None


def get_tty():
    """Get TTY of the Claude process."""
    import subprocess
    try:
        result = subprocess.run(
            ["ps", "-p", str(os.getppid()), "-o", "tty="],
            capture_output=True, text=True, timeout=2,
        )
        tty = result.stdout.strip()
        if tty and tty not in ("??", "-"):
            return tty if tty.startswith("/dev/") else "/dev/" + tty
    except Exception:
        pass
    return None


def build_state(data):
    """Build state dict from hook event data."""
    return {
        "session_id": data.get("session_id", "unknown"),
        "cwd": data.get("cwd", ""),
        "event": data.get("hook_event_name", ""),
        "pid": os.getppid(),
        "tty": get_tty(),
        "tool": data.get("tool_name"),
        "tool_input": data.get("tool_input", {}),
    }


def main():
    try:
        data = json.load(sys.stdin)
    except json.JSONDecodeError:
        sys.exit(1)

    event = data.get("hook_event_name", "")
    state = build_state(data)

    # --- PermissionRequest: the only event that needs a decision ---
    if event == "PermissionRequest":
        config = read_config()

        if config["turbo_mode"]:
            delay = config["auto_allow_delay_seconds"]

            if delay <= 0:
                # Instant auto-allow — notify app for display, don't wait
                state["status"] = "auto_allowed"
                notify_app(state)
                allow()
            else:
                # Delayed auto-allow — give user a window to deny
                state["status"] = "waiting_for_approval"
                state["auto_allow"] = True
                state["auto_allow_delay"] = delay

                response = notify_and_wait(state, delay)

                if response and response.get("decision") == "deny":
                    deny(response.get("reason", "Denied by user"))

                # Timeout or allow — auto-approve
                allow()
        else:
            # Turbo off — normal flow, wait up to 5 minutes for user
            state["status"] = "waiting_for_approval"
            response = notify_and_wait(state, 300)

            if response:
                decision = response.get("decision", "ask")
                if decision == "allow":
                    allow()
                elif decision == "deny":
                    deny(response.get("reason", "Denied by user"))

            # No response — fall through to Claude Code's built-in prompt
            sys.exit(0)

    # --- All other events: just notify the app ---
    elif event == "PreToolUse":
        state["status"] = "running_tool"
        tool_use_id = data.get("tool_use_id")
        if tool_use_id:
            state["tool_use_id"] = tool_use_id
        notify_app(state)

    elif event == "PostToolUse":
        state["status"] = "processing"
        tool_use_id = data.get("tool_use_id")
        if tool_use_id:
            state["tool_use_id"] = tool_use_id
        notify_app(state)

    elif event == "UserPromptSubmit":
        state["status"] = "processing"
        notify_app(state)

    elif event == "Notification":
        notification_type = data.get("notification_type")
        if notification_type == "permission_prompt":
            sys.exit(0)
        state["status"] = "waiting_for_input" if notification_type == "idle_prompt" else "notification"
        state["notification_type"] = notification_type
        state["message"] = data.get("message")
        notify_app(state)

    elif event in ("Stop", "SubagentStop"):
        state["status"] = "waiting_for_input"
        notify_app(state)

    elif event == "SessionStart":
        state["status"] = "waiting_for_input"
        notify_app(state)

    elif event == "SessionEnd":
        state["status"] = "ended"
        notify_app(state)

    elif event == "PreCompact":
        state["status"] = "compacting"
        notify_app(state)


if __name__ == "__main__":
    main()
