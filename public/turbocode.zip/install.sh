#!/bin/bash
# Install TurboCode
# This script deploys the app and hook script

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_NAME="TurboCode.app"
HOOK_SCRIPT="turbo-hook.py"
CONFIG_FILE="claude-island-config.json"

echo "=== Installing TurboCode ==="

# 1. Kill if already running and clean up
echo "Stopping TurboCode..."
killall "TurboCode" 2>/dev/null || true
sleep 1
rm -f /tmp/claude-island.pid /tmp/claude-island.sock

# 2. Copy app to /Applications
echo "Installing app to /Applications..."
if [ -d "/Applications/$APP_NAME" ]; then
    rm -rf "/Applications/$APP_NAME"
fi
cp -R "$SCRIPT_DIR/$APP_NAME" "/Applications/$APP_NAME"

# 3. Remove quarantine attribute
xattr -rd com.apple.quarantine "/Applications/$APP_NAME" 2>/dev/null || true

# 4. Ad-hoc code sign
echo "Code signing (ad-hoc)..."
codesign --force --deep --sign - "/Applications/$APP_NAME" 2>/dev/null || echo "Warning: codesign failed, app may need manual approval in System Settings"

# 5. Install the hook script
echo "Installing hook script..."
mkdir -p ~/.claude/hooks
cp "$SCRIPT_DIR/$HOOK_SCRIPT" ~/.claude/hooks/$HOOK_SCRIPT
chmod +x ~/.claude/hooks/$HOOK_SCRIPT

# 6. Install config file (only if not already present)
if [ ! -f ~/.claude/$CONFIG_FILE ]; then
    echo "Installing default config..."
    echo '{"turbo_mode": false, "auto_allow_delay_seconds": 1}' > ~/.claude/$CONFIG_FILE
fi

echo ""
echo "=== Installation Complete ==="
echo ""
echo "To launch: open '/Applications/$APP_NAME'"
echo ""
echo "Configuration: ~/.claude/$CONFIG_FILE"
echo "  turbo_mode:                false (toggle in the notch panel)"
echo "  auto_allow_delay_seconds:  1     (0-10s delay before auto-approve)"
