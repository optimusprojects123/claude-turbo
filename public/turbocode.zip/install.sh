#!/bin/bash
# Install Claude Island Custom
# This script deploys the custom app and hook script

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_NAME="Claude Island Custom.app"
HOOK_SCRIPT="claude-island-state.py"
CONFIG_FILE="claude-island-config.json"

echo "=== Installing Claude Island Custom ==="

# 1. Kill the original app if running
echo "Stopping original Claude Island..."
killall "Claude Island" 2>/dev/null || true
sleep 1

# 2. Copy custom app to /Applications
echo "Installing app to /Applications..."
if [ -d "/Applications/$APP_NAME" ]; then
    rm -rf "/Applications/$APP_NAME"
fi
cp -R "$SCRIPT_DIR/$APP_NAME" "/Applications/$APP_NAME"

# 3. Remove quarantine attribute so macOS allows running it
xattr -rd com.apple.quarantine "/Applications/$APP_NAME" 2>/dev/null || true

# 4. Ad-hoc code sign so macOS doesn't block it
echo "Code signing (ad-hoc)..."
codesign --force --deep --sign - "/Applications/$APP_NAME" 2>/dev/null || echo "Warning: codesign failed, app may need manual approval in System Settings"

# 5. Install the custom hook script
echo "Installing hook script..."
cp "$SCRIPT_DIR/$HOOK_SCRIPT" ~/.claude/hooks/$HOOK_SCRIPT
chmod +x ~/.claude/hooks/$HOOK_SCRIPT

# 6. Install config file
echo "Installing config..."
cp "$SCRIPT_DIR/$CONFIG_FILE" ~/.claude/$CONFIG_FILE

# 7. Update Claude settings to use the custom hook
# (No change needed - settings.json already points to ~/.claude/hooks/claude-island-state.py)

echo ""
echo "=== Installation Complete ==="
echo ""
echo "To launch: open '/Applications/$APP_NAME'"
echo ""
echo "Configuration: ~/.claude/claude-island-config.json"
echo "  auto_approve_all:       false (set true to auto-approve everything)"
echo "  auto_approve_subagents: true  (sub-agent tools auto-approved)"
echo ""
echo "To toggle auto-approve: edit ~/.claude/claude-island-config.json"
echo "  Set auto_approve_all to true to approve ALL permissions automatically."
